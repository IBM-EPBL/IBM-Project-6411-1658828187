const express = require("express");
const bodyParser = require("body-parser");
const https = require("https");
const ejs = require("ejs")
const app = express();
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
let credentials = {
    username : "heart disease",
    password : "sgltv123"
}
let utilities = {
    age:"",
    
    diaBp:"",
    chestpt:"",
    glucose:"",
    heartRate:"",
    sex:"",
    sysBp:"",
    totChol:"",
    prediction:""
}

app.get("/",(req,res)=>{
    res.render("login");
})
app.get("/heart-disease",(req,res)=>{
    var result="";
    if(utilities.prediction[0]===0){
         result = "less chance of heart attack";
    }else{
         result = "More chance of heart attack";
    }
    res.render("index",{age:utilities.age,diaBp:utilities.diaBp,chestpt:utilities.chestpt,glucose:utilities.glucose,heartrate:utilities.heartRate,sex:utilities.sex,sysbp:utilities.sysBp,totchol:utilities.totChol,result:result});
    console.log(utilities);
    
    
})
app.get("/error",(req,res)=>{
	res.send("<h1>Invalid username or password</h1>");
})

app.post("/heart-disease",(req,res)=>{

    let age = req.body.age;
    
    let chol = req.body.chol;
    let diabp = req.body.diabp;
    let chestpt = req.body.diabetes;
    let glucose = req.body.glucose;
    let heartRate = req.body.heartrate;
    let sex = req.body.sex;
    let sysbp = req.body.sysbp;
    const url = "https://heartapi.herokuapp.com/predict?age="+age+"&sex="+sex+"&cigs="+chestpt+"&chol="+chol+"&sBP="+sysbp+"&dia=0&dBP="+diabp+"&gluc="+glucose+"&hRate="+heartRate;
    https.get(url,(response)=>{
        if(response.statusCode==404){
            res.redirect("/error");
        }
        response.on("data",(data)=>{
                let heartData=JSON.parse(data);
                let agedata = heartData.data.age;
                
                let choldata = heartData.data.totChol;
                let diabpdata=heartData.data.diaBP;
                let glucosedata = heartData.data.glucose;
                let heartRatedata = heartData.data.heartRate;
                let sexdata = heartData.data.sex;
                let sysbpdata = heartData.data.sysBP;
                let chestpt = heartData.data.cigsPerDay;
                let predictdata =heartData.prediction;
                utilities.age=agedata;
                
                utilities.diaBp=diabpdata;
                utilities.totChol=choldata;
                utilities.chestpt=chestpt;
                utilities.glucose=glucosedata;
                utilities.heartRate=heartRatedata;
                utilities.sex=sexdata;
                utilities.sysBp=sysbpdata;
                utilities.prediction=predictdata;
                res.redirect("/heart-disease#detailed");
        })
    })
    
    
})
app.post("/",(req,res)=>{
    let username = req.body.username;
    let pwd = req.body.password;
    if (username === credentials.username && pwd === credentials.password) {
            res.redirect("/heart-disease");
    }else{
        res.redirect("/error");
    }

})

app.listen(3000,()=>{
    console.log("Server started at port 3000......");
})
